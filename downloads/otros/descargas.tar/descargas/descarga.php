<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//R1 Leo usuario y password

$user = filter_input(INPUT_POST,'usuario');
$pass = filter_input(INPUT_POST,'password');
$adm=false;
if ($user == 'admin'&& $pass=='admin')
    $adm=true;




//Requisito R2 y R2.1
$origen=$_FILES['fichero']['tmp_name'];
$nombreFichero=$_FILES['fichero']['name'];
$tipo = $_FILES['fichero']['type'];
$tipo_fichero= explode('/',$tipo);
switch  ($tipo_fichero[0]){
    case 'audio':
        $dir_destino="/var/www/descargas/uploads/musica";
        break;
    case 'image':
        $dir_destino="/var/www/descargas/uploads/imagenes";
        break;
    default:
        $dir_destino="/var/www/descargas/uploads/otros";
    
}

$destino=$dir_destino .'/'.$nombreFichero;


if (move_uploaded_file($origen, $destino))
        echo "Fichero subido de forma correcta";
else
    echo "Error!!!! no se ha podido subir el fichero ";
?>

<form action="." method="POST">
    
    <?php

if ($adm){
    $fMusica = scandir("/var/www/descargas/uploads/musica/");
    $fImagenes = scandir("/var/www/descargas/uploads/imagenes/");
    $fOtros = scandir("/var/www/descargas/uploads/otros/");
    echo "<fielset><legend>Canciones subidas </legend>";
    foreach ($fMusica as $cancion){
        if (($cancion !== '.') && ($cancion !== '..'))
            echo "<input type=checkbox name = musica[] value =$cancion />$cancion<br />";
    } 
    echo "</fielset><fielset><legend>Imagenes subidas </legend>";
    foreach ($fImagenes as $imagen){
        if (($imagen !== '.')&& ($imagen !== '..'))
            echo "<input type=checkbox name = imagen[] value =$imagen />$imagen<br />";
    } echo "</fielset><fielset><legend>Otros ficheros subidas </legend>";
    foreach ($fOtros as $otro){
        if (($otro !== '.') && ($otro !== '..'))
            echo "<input type=checkbox name = otros[] value =$otro />$otro<br />";
    } 
    echo "</fielset>";
    
}
