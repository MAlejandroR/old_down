<!-- REQUISITOS DE LA APLICACIÓN ->
(10 Minutos . 13:10)

R1 = El usuario se identifica (nombre y password)
R2 = Todos usuario puede subir un fichero (uploads)
R2.1 = Los ficheros subidos se ubicarán en carpetas según el tipo  (auido, imagen, otros)
R3 = El usuario admin puede publicar ficheros (donwload)
R3.1 = si usuario admin listado de ficheros con checkbox 

R5 = 20 M tamaño máximo de los ficheros
R6 = Todo usuario podrá acceder a los ficheros publicados (donwload)



<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <fieldeset>
        <legend>Descarga de ficheros</legend>
        <form action="descarga.php" method="POST" enctype="multipart/form-data">
            Usuario = <input type="text" name="usuario" id="">
            Password = <input type="password" name="password" id=""><br />
            
            
            
           <!-- <input type="hidden" name="MAX_FILE_SIZE" value="10M"> -->
            Selecciona fichero 
            <input type="file" name="fichero" id="" >
            <br />
            <input type="submit" value="descarga" name="descarga">
        </form>
    </fieldeset>
            
    </body>
</html>
