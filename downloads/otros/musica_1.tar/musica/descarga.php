<form action="descarga.php" method="POST">
      <p><a href="/audio/pron-pers-1.mp3" class="sm2_button" title="Listen - Audio">Play</a></p>
    <?php
    /*
     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */
//Cualquier usuario puede subir y ver/escuchar lo que esté disponible
    $usuario = $_POST['usuario'];
    $pass = $_POST['pass'];
    $adm = false;
    if (($usuario == "admin") && ($pass = "admin"))
        $adm = true;



//Guardar el fichero en el servidor
    $fichero = $_FILES['fichero']['name'][0];
    $origen = $_FILES['fichero']['tmp_name'][0];
    print_r($fichero);
    $tipo = $_FILES['fichero']['type'][0];
    var_dump($tipo);
    $dirImagenes="/var/www/musica/download/imagenes";
    $dirCanciones="/var/www/musica/download/canciones";
    echo "tipo = $tipo<br />";
//La persona accede a la app registrandose (usuario y email)
    $dir_subidas = '/var/www/musica/uploads/';
    $a = strpos($tipo, "ppppp");
    var_dump($a);
    echo "Encontrado -image- en $tipo en la posición $a<br/>";
    if (strpos($tipo, "audio") !== false) {
        echo "El fichero $fichero es de tipo audio";
        $dir_subidas = '/var/www/musica/uploads/musica/';
    }
    if (strpos($tipo, "image") !== false) {
        echo "El fichero $fichero es de tipo imagen";
        $dir_subidas = '/var/www/musica/uploads/imagenes/';
    }
    //Listamos las imágenes y música que se puede ver/escuchar
    $canciones = scandir("/var/www/musica/download/canciones");
    $imagenes = scandir("/var/www/musica/download/imagenes");


    if ($adm) {
        echo "<fieldset> <legend>Canciones</legend>";
        foreach ($canciones as $cancion) {
            if (($cancion != '.') && ($cancion != '..')) { 
                echo "<input type='checkbox' name='cancion[]' value='$cancion' />  $cancion<br />";
            }
        }
        echo "</fieldset>";
        echo "<fieldset> <legend>Musica</legend>";
        foreach ($imagenes as $imagen) {
            if (($imagen != '.') && ($imagen != '..')) {
                echo "<input type='checkbox' name='imagen[]' value='$imagen' />  $imagen<br />";
            }
        }
        echo "</fieldset>";
    }else {//En este caso solo visualizo sin poder seleccionar
        echo "<fieldset> <legend>Canciones</legend>";
        foreach ($canciones as $cancion) {
            if (($cancion != '.') && ($cancion != '..')) { 
              echo "<a href='http://localhost/musica/download/canciones/$cancion' >$cancion</a><br />";
            }
        }
        echo "</fieldset>";
        echo "<fieldset> <legend>Musica</legend>";
        foreach ($imagenes as $imagen) {
            if (($imagen != '.') && ($imagen != '..')) {
                echo "<input type='checkbox' name='imagen[]' value='$imagen' />  $imagen<br />";
            }
        }
        echo "</fieldset>";
        
        
    }
    
        ?>     
    <!--
    
    
    
    
        //Solo el admin/admin puede chequear qué ficheros se pueden ver/escuchar
        //Los ficheros que se pueden escuchar también se podrán descargar
        //Para ello vamos a organizar 4 directorios
        // upload/musica 
        // upload/imagenes
        // download/musica
        // download/imagenes
        //Si el fichero es de sonido va a la carpeta upload/musica
        //Si el ficheor es de imágenes va  a la carpeta upload/imagenes
        //Esto lo puede hacer cualquier usuario
        //Escribimos en un fichero usuario y momento y fichero que ha subido, y la ip desde dónde lo ha hecho
        //Si el usuario es admin /admin  tendrá un check por cada imagen y canción
        //Si las picas quedarán accesibles para que cualquier usuario las pueda ver escuchar
        //directorio donde dejaré las canciones
    
        $destino = $dir_subidas . $fichero;
        //echo $destino ."-".$origen[0];
    
        if (move_uploaded_file($origen, $destino))
        echo ('file load ok<br />');
        else
        echo ("Danger!!!!! <br />");
        if (isset($_POST['sonar'])) {
        echo "<audio src='http://localhost/musica/uploads/a.mp3' autoplay='true' >";
            }
            ?>
            <input type="submit" value="sonar" name = "sonar">
            </form>
    
    -->